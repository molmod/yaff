If you encounter a problem
##########################

Get in touch with us on the `Yaff
mailing list <https://groups.google.com/forum/#!forum/ninjaff>`_.

How to cite Yaff
################

In anticipation of the first announcement of Yaff in a scientific journal, please refer to Yaff as follows:

"T. Verstraelen, L. Vanduyfhuys, S. Vandenbrande 'Yaff, yet another force
field', http://molmod.ugent.be/software/"

#!/bin/bash

rm -v output.h5
rm -v rdf.png
rm traj.xyz 

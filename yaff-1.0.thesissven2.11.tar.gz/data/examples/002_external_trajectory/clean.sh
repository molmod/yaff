#!/bin/bash

rm -v rdf.png
rm -v trajectory.h5
